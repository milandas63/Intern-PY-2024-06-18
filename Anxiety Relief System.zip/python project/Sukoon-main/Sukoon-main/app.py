from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/runcode', methods=['POST'])
def run_code():
    try:
        # Replace 'your_script.py' with the path to your Python script
        subprocess.run(['python', 'main.py'])
        return jsonify({'success': True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)

import face_recognition
import cv2
import numpy as np
import csv
import os
from datetime import datetime
from PIL import Image

def resize_image(image_path, size=(800, 800)):
    image = Image.open(image_path)
    image = image.resize(size, Image.LANCZOS)
    image = image.convert("RGB")  # Ensure the image is in RGB format
    return np.array(image)

base_dir = os.path.dirname(__file__)
photos_dir = os.path.join(base_dir, "photos")

# Print file paths for verification
print("Aryan image path:", os.path.join(photos_dir, "aryan.jpg"))

video_capture = cv2.VideoCapture(0)

if not video_capture.isOpened():
    print("Error: Could not open webcam.")
    exit()

try:
    aryan_image = resize_image(os.path.join(photos_dir, "aryan.jpg"))
    aryan_encoding = face_recognition.face_encodings(aryan_image)[0]

    asish_image = resize_image(os.path.join(photos_dir, "asish.jpg"))
    asish_encoding = face_recognition.face_encodings(asish_image)[0]

    patri_image = resize_image(os.path.join(photos_dir, "patri.jpg"))
    patri_encoding = face_recognition.face_encodings(patri_image)[0]

    bi_image = resize_image(os.path.join(photos_dir, "bi.jpg"))
    bi_encoding = face_recognition.face_encodings(bi_image)[0]

    kh_image = resize_image(os.path.join(photos_dir, "kh.jpg"))
    kh_encoding = face_recognition.face_encodings(kh_image)[0]

    deba_image = resize_image(os.path.join(photos_dir, "deba.jpg"))
    deba_encoding = face_recognition.face_encodings(deba_image)[0]

    md_image = resize_image(os.path.join(photos_dir, "md.jpg"))
    md_encoding = face_recognition.face_encodings(md_image)[0]

except MemoryError:
    print("MemoryError: Unable to process the image due to insufficient memory.")
    exit()
except IndexError:
    print("Error: Face encoding failed. Ensure the images contain clear faces.")
    exit()

known_face_encoding = [
    aryan_encoding,
    asish_encoding,
    patri_encoding,
    bi_encoding,
    kh_encoding,
    deba_encoding,
    md_encoding
]

known_faces_names = [
    "aryan",
    "asish",
    "patri",
    "bi",
    "kh",
    "deba",
    "md"
]

students = known_faces_names.copy()

face_locations = []
face_encodings = []
face_names = []
s = True

now = datetime.now()
current_date = now.strftime("%Y-%m-%d")

csv_file_path = os.path.join(base_dir, f"{current_date}.csv")
print(f"Saving attendance records to: {csv_file_path}")

with open(csv_file_path, 'w+', newline='') as f:
    lnwriter = csv.writer(f)
    lnwriter.writerow(["Name", "Time"])  # Add header row for clarity

    while True:
        ret, frame = video_capture.read()
        if not ret:
            print("Failed to grab frame")
            break

        # Convert the image to RGB format
        rgb_frame = frame[:, :, ::-1]
        small_frame = cv2.resize(rgb_frame, (0, 0), fx=0.25, fy=0.25)

        if s:
            face_locations = face_recognition.face_locations(small_frame)
            face_encodings = face_recognition.face_encodings(small_frame, face_locations)
            face_names = []

            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(known_face_encoding, face_encoding)
                name = ""
                face_distance = face_recognition.face_distance(known_face_encoding, face_encoding)
                best_match_index = np.argmin(face_distance)
                if matches[best_match_index]:
                    name = known_faces_names[best_match_index]

                face_names.append(name)
                if name in known_faces_names:
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    bottomLeftCornerOfText = (10, 100)
                    fontScale = 1.5
                    fontColor = (255, 0, 0)
                    thickness = 3
                    lineType = 2

                    cv2.putText(frame, name + ' Present',
                                bottomLeftCornerOfText,
                                font,
                                fontScale,
                                fontColor,
                                thickness,
                                lineType)

                    if name in students:
                        students.remove(name)
                        current_time = datetime.now().strftime("%H-%M-%S")  # Update the current time correctly
                        lnwriter.writerow([name, current_time])
                        print(f"Logged {name} at {current_time}")  # Debug print to verify logging

        cv2.imshow("attendance system", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

video_capture.release()
cv2.destroyAllWindows()
